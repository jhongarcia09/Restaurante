package com.example.Restaurantefinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantefinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantefinalApplication.class, args);
	}

}
