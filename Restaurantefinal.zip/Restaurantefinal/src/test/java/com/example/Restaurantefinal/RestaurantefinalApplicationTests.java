package com.example.Restaurantefinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantefinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
